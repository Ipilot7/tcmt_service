@echo off
    cd /d "C:\ss"
    title Equipment Status Agent
    :: Запуск без окна и без ожидания завершения
    start /b PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\ss\device_agent.ps1"
    exit